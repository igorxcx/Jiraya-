//database
echo internal storage online
sleep2 "database"
var url:'https://'
fi
